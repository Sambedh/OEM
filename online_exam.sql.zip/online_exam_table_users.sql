
-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) UNSIGNED NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `username` varchar(100) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(254) NOT NULL,
  `activation_selector` varchar(255) DEFAULT NULL,
  `activation_code` varchar(255) DEFAULT NULL,
  `forgotten_password_selector` varchar(255) DEFAULT NULL,
  `forgotten_password_code` varchar(255) DEFAULT NULL,
  `forgotten_password_time` int(11) UNSIGNED DEFAULT NULL,
  `remember_selector` varchar(255) DEFAULT NULL,
  `remember_code` varchar(255) DEFAULT NULL,
  `created_on` int(11) UNSIGNED NOT NULL,
  `last_login` int(11) UNSIGNED DEFAULT NULL,
  `active` tinyint(1) UNSIGNED DEFAULT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `company` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `reference_id` int(11) DEFAULT NULL,
  `subscription` date DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `ip_address`, `username`, `password`, `email`, `activation_selector`, `activation_code`, `forgotten_password_selector`, `forgotten_password_code`, `forgotten_password_time`, `remember_selector`, `remember_code`, `created_on`, `last_login`, `active`, `first_name`, `last_name`, `company`, `phone`, `reference_id`, `subscription`, `image`) VALUES
(1, '127.0.0.1', 'administrator', '$2y$12$N.6yBIMPsm0Go2lPOD62iuj7CX4noPFikvSD5Fov5q.bmo2kGdDiG', 'admin@admin.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1268889823, 1604665448, 1, 'Admin', 'istrator', 'ADMIN', '0', NULL, NULL, ''),
(16, '127.0.0.1', NULL, '$2y$10$rzJe4d6uXYw9JZ3qtPVawO0Cb.i3BFLhT2HsXe441H7uYZk/tAkYi', 'university.test@online.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1603360485, 1605160425, 1, 'University', 'Test', 'University', '1234567890', NULL, '2020-11-12', ''),
(24, '127.0.0.1', NULL, '$2y$10$3Kwk3e9sgkYITNYj/plSsO0aHkPA23zSCqlXRh607QrpHSTrVp4rW', 'manil@university.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1603363857, 1605177762, 1, 'manil', 'test', NULL, '1234567890', 16, NULL, '24photo-1427751840561-9852520f8ce8.jpg'),
(25, '127.0.0.1', NULL, '$2y$10$FjlReFRi6QLpPceozxEsEuG4Z7Mt55AwaxUut4wZStB.iszfMC1.6', 'pukar@university.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1603364134, 1604055885, 1, 'Pukar', 'Test', NULL, '1234567890', 16, NULL, ''),
(26, '127.0.0.1', NULL, '$2y$10$QwKvlCJeNw7S8W1ZpNg6e.YZ08wYbgnOteNpY7A6pnMStFUISl86q', 'madan@university.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1603364197, 1605177648, 1, 'Madan', 'Test', NULL, '1234567890', 16, NULL, ''),
(37, '127.0.0.1', NULL, '$2y$12$3gqTDnXBe9tBYBmubzClm.1cSnVRuVJQ.BgiTxMzaMh1CO2zlh0g6', 'sambedhkandel@gmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1604311015, 1605156488, 1, 'Sambedh', 'Kandel', NULL, '9108764402', NULL, NULL, ''),
(38, '127.0.0.1', NULL, '$2y$10$hpuSm533lc4pV63CV7tkrOUbsxj9.olooOYb5TJ7pyfx0TAlYg39S', 'sambedh.123@gmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1604311325, 1604995406, 1, 'Sambedh', 'Kandel', 'Hajmola', '9036141315', NULL, '2020-11-30', ''),
(39, '127.0.0.1', NULL, '$2y$10$T7QyTqkKUJx4mx50sjoOqeRwYBzNhJIYwIGSTG3dAy/Bbsg4qqcNW', 'test@hajmola.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1604907250, NULL, 1, 'test', 'Student', NULL, '1542165826', 38, NULL, NULL),
(40, '127.0.0.1', NULL, '$2y$10$ll6jCjbo03nzFxyBtkERMOYUf9.DQNE8OVoW4KCQFxAOTH1oyeyBG', 'dummy@hajmola.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1604922455, NULL, 1, 'dummy1', 'test1', NULL, '1346824422', 38, NULL, NULL),
(41, '127.0.0.1', NULL, '$2y$10$41FHGaoJPCy2KHoUyhYSH.3TCLlaR1suAquXpmN.FfbCyQWcq3Aqm', 'dummy2@hajmola.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1604922531, NULL, 1, 'dummy 2', 'test 2', NULL, '1234567890', 38, NULL, NULL),
(42, '127.0.0.1', NULL, '$2y$10$0Iu94VXpGWfukm.i0zxpd.RB9pbDdnr1Vmssh6P6733MOaL7xNVfC', 'dummy3@hajmola.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1604922583, NULL, 1, 'dummy 3', 'test 3', NULL, '1234567890', 38, NULL, NULL),
(43, '127.0.0.1', NULL, '$2y$10$nMVQFf1nhnG6O9SZf1wScOt7sqRkzae4CYx.83XyghW.QMbnPTZkG', 'lokesh@university.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1604986935, NULL, 1, 'Lokesh', 'Test', NULL, '1234567890', 16, NULL, NULL),
(44, '127.0.0.1', NULL, '$2y$10$0WNNTndpiH2M1iT6XnFTgesqJWmXCNKGmi8/cmnu7m/IS1ylZt4cK', 'mahesh@university.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1604987661, NULL, 1, 'Mahesh', 'test', NULL, '1234567890', 16, NULL, NULL),
(45, '127.0.0.1', NULL, '$2y$10$nEXvfl8h.crx/WveQjRCAeANPqJG0/Kp1AvzN9h.k8GHjIvDKgTr2', 'bipin@university.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1604987790, NULL, 1, 'Bipin', 'test', NULL, '1234567891', 16, NULL, NULL),
(46, '127.0.0.1', NULL, '$2y$10$E.59PZO/uuk9J848F/rDdOLDkTDHDDCp1OFnS/NiTcQmoAuz6ATW2', 'sita@university.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1604988735, NULL, 1, 'Sita', 'Test', NULL, '1234567890', 16, NULL, NULL),
(47, '127.0.0.1', NULL, '$2y$10$EmFpjHKapPzUdWQ4yB6kxeeFk0rH5gmK2oueHrvNGoqTSNRCqfbLi', 'pooja@university.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1604988799, NULL, 1, 'Pooja', 'test', NULL, '1234567890', 16, NULL, NULL),
(48, '127.0.0.1', NULL, '$2y$10$OzDXBrauo/zyz34/BVmPEemCczmFJM.2uK.8AnESudVLvbxDZT.W2', 'dummy@university.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1604989215, NULL, 1, 'dummy', 'dummy', NULL, '1234567888', 16, NULL, NULL),
(49, '127.0.0.1', NULL, '$2y$10$M3YyoRNHO8zX/NZTP.gr1.5DwmttDMKNILgvI97U2XJgTVCqYNc2C', 'dummy1@university.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1604989248, NULL, 1, 'dummy1', 'test', NULL, '1234567888', 16, NULL, NULL),
(50, '127.0.0.1', NULL, '$2y$10$tCoyl9/HCAqGCKD5v1fKqeG.4vT98GbZt10PqhfG95r.jM2CRye1S', 'dummy2@university.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1604989307, NULL, 1, 'dummy2', 'Test', NULL, '1234567890', 16, NULL, NULL),
(51, '127.0.0.1', NULL, '$2y$10$/YUu8SUqb4p9Vl2RrsOXLOZt9up6O9aAINnJ6Pd5tbjM045JpikUm', 'dummy3@university.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1604989325, NULL, 1, 'dummy3', 'Test', NULL, '1234567890', 16, NULL, NULL),
(52, '127.0.0.1', NULL, '$2y$10$STg/faxlcW5LI6oj42ND6uFtiVRohsiSa31.zLCVf0GhRUH8vEaV.', 'dummy4@university.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1604989342, NULL, 1, 'dummy4', 'Test', NULL, '1234567890', 16, NULL, NULL),
(53, '127.0.0.1', NULL, '$2y$10$X5qRXMhDwEMFRSb3qrOK7ude0HUQesGWovdEk9Zv2zHmU4.SvBfbO', 'dummy5@university.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1604989358, NULL, 1, 'dummy5', 'Test', NULL, '1234567890', 16, NULL, NULL),
(54, '127.0.0.1', NULL, '$2y$10$8uM1A6izffmJOTbnPr0NXuk..gDKR/r9TqXdPiSroO.MZhAEphskO', 'dummy6@university.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1604989372, NULL, 1, 'dummy6', 'Test', NULL, '1234567890', 16, NULL, NULL),
(55, '127.0.0.1', NULL, '$2y$10$.YMGTkmks.WPBIjS76UgBecQqMFmQlWsONGJQFzSGm7Rui9PD0q/6', 'dummy7@university.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1604989389, NULL, 1, 'dummy7', 'Test', NULL, '1234567890', 16, NULL, NULL),
(56, '127.0.0.1', NULL, '$2y$10$0KCxs893XGd3CwLH/Qw6IO7C0Wvc0P98nzsywk5I1EpJuKMj/4uCq', 'dummy8@university.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1604989403, NULL, 1, 'dummy8', 'Test', NULL, '1234567890', 16, NULL, NULL),
(57, '127.0.0.1', NULL, '$2y$10$nl.B1umCEkFINg/X7ynuWeQO7nquNgTAs9WcFYYlyHUQL8OC3/.Qe', 'dummy9@university.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1604989418, NULL, 1, 'dummy9', 'Test', NULL, '1234567890', 16, NULL, NULL),
(58, '127.0.0.1', NULL, '$2y$10$12dW29ACQlnG8j1GFbz6cuDN.iH1jJsepnkMJcbth/3JwTf59O6Uu', 'dummy10@university.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1604989434, NULL, 1, 'dummy10', 'Test', NULL, '1234567890', 16, NULL, NULL),
(59, '127.0.0.1', NULL, '$2y$10$Vt/8sjuYGo0Js1iBCICsjOaE97ShquaoTjI0ZnDvs.x8gsNHwvTJ.', 'dummy11@university.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1604989449, NULL, 1, 'dummy11', 'Test', NULL, '1234567890', 16, NULL, NULL),
(60, '127.0.0.1', NULL, '$2y$10$lgokM/UWPjOIFnBNtHPmau87J1odLcuVaZSv9HLyYIGwK55LaWM96', 'dummy12@university.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1604989463, NULL, 1, 'dummy12', 'Test', NULL, '1234567890', 16, NULL, NULL),
(61, '127.0.0.1', NULL, '$2y$10$npkFyVEW2lMoFhpF/T5mp.D/15Lwn6YqdqgBOEY3rQ16Vp8KRgbhm', 'dummy13@university.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1604989478, NULL, 1, 'dummy13', 'Test', NULL, '1234567890', 16, NULL, NULL),
(62, '127.0.0.1', NULL, '$2y$10$Ba/VP.JWrh0zj1.HSal92eaHoxdfYk7JJm6SGhz8/hTkVrSPOMPNm', 'dummy14@university.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1604989494, NULL, 1, 'dummy14', 'Test', NULL, '1234567890', 16, NULL, NULL),
(63, '127.0.0.1', NULL, '$2y$10$74cuU2HLGxOn6nVpZ5v7X.kHWKb1Lb4XAl1BcP5S0UpTP29da.Gwy', 'dummy15@university.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1604989515, NULL, 1, 'dummy15', 'Test', NULL, '1234567890', 16, NULL, NULL),
(64, '127.0.0.1', NULL, '$2y$10$idvNHK9XZU1rmvCR3KEHhuxN89HMsZaWG2FtlzCCgUHFRYIJRhBPW', 'dummy4@hajmola.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1604995437, NULL, 1, 'dummy4', 'Test', NULL, '1234567890', 38, NULL, NULL),
(65, '127.0.0.1', NULL, '$2y$10$mzpGyHiNsufhvaReucdGOuFqjjM0E.uhdpeNZL4Uh1aMrA.ckle0W', 'dummy5@hajmola.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1604995499, NULL, 1, 'dummy5', 'Test', NULL, '1234567890', 38, NULL, NULL),
(66, '127.0.0.1', NULL, '$2y$10$7oZxLQSKXWuq62pBIzEwJub6R4LRv6M4VFeWDZG9A382J3HQHUW9.', 'dummy6@hajmola.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1604995546, NULL, 1, 'dummy6', 'Test', NULL, '1234567890', 38, NULL, NULL),
(67, '127.0.0.1', NULL, '$2y$10$WM4XEQ07OBIRj0wjEr8b7edgKTXOf..AR07D99LPZCG0VfixEHDny', 'dummy7@hajmola.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1604995565, NULL, 1, 'dummy7', 'Test', NULL, '1234567890', 38, NULL, NULL),
(68, '127.0.0.1', NULL, '$2y$10$ESkMz9jw7WufuARx8iTdZ.nNzePLOAbk9Kxuizlg2EuGkuhymlxoy', 'dummy8@hajmola.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1604995587, NULL, 1, 'dummy8', 'Test', NULL, '1234567890', 38, NULL, NULL);
