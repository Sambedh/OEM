
-- --------------------------------------------------------

--
-- Table structure for table `users_groups`
--

CREATE TABLE `users_groups` (
  `id` int(11) UNSIGNED NOT NULL,
  `user_id` int(11) UNSIGNED NOT NULL,
  `group_id` mediumint(8) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users_groups`
--

INSERT INTO `users_groups` (`id`, `user_id`, `group_id`) VALUES
(1, 1, 1),
(2, 1, 2),
(46, 16, 5),
(41, 24, 3),
(47, 25, 3),
(43, 26, 2),
(39, 37, 1),
(40, 38, 5),
(48, 39, 3),
(49, 40, 3),
(50, 41, 3),
(51, 42, 3),
(52, 43, 2),
(53, 44, 3),
(54, 45, 3),
(55, 46, 3),
(56, 47, 3),
(57, 48, 3),
(58, 49, 3),
(59, 50, 3),
(60, 51, 3),
(61, 52, 3),
(62, 53, 3),
(63, 54, 3),
(64, 55, 3),
(65, 56, 3),
(66, 57, 3),
(67, 58, 3),
(68, 59, 3),
(69, 60, 3),
(70, 61, 3),
(71, 62, 3),
(72, 63, 3),
(73, 64, 3),
(74, 65, 3),
(75, 66, 3),
(76, 67, 3),
(77, 68, 3);
