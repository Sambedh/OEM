
-- --------------------------------------------------------

--
-- Table structure for table `temp_answers`
--

CREATE TABLE `temp_answers` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `exam_sub_id` int(11) NOT NULL,
  `mcq_id` int(11) NOT NULL,
  `option_id` int(11) NOT NULL,
  `time_left` int(11) NOT NULL,
  `time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
